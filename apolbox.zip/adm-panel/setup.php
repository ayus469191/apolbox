<?php

define( 'AXPATH', dirname(dirname(__FILE__) ) . 'ax-setting.php' );